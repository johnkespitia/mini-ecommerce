ALTER TABLE products
    ADD description text,
    ADD images varchar(200);