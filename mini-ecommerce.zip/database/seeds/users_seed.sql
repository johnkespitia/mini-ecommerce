insert into users (username, password, name, email, rol_id ) values ('crm_admin',md5('CRM4Dm1N!'), 'CRM Administrator' ,'admin@crmhidrolavadorasmar.com',1);
