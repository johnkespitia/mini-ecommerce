insert into rols (name) values ('ADMIN'),('ADVISOR');
